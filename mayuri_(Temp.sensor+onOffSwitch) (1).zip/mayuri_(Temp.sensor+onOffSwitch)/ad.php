<?php

$b =$_GET['n'];

echo"STATUS : $b";

$con=pg_connect("host=localhost user=project password=pro123 dbname=pro")
	or die("unable to connect database");

//$qry="insert into switch values(1,1)";

if($b === "ON")
{
	$qry="update switch set status=1 where id=1;";
}
if($b === "OFF")
{
        $qry="update switch set status=10 where id=1";
}

pg_query($con,$qry) or die("Unable to UPDATE");
pg_close($con);
?>
