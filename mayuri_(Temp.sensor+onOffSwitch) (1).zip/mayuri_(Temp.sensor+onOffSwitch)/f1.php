<html>
	<body>
        <a href="l2try.php" style="width:100px"><img src="pre.png" alt="PREVIOUS" style="width:80px;height:80px;margin-left:0px;border:0"></a>

		<a href="display.php" target="right" align="center"><d1><h2> Current Temperature</h2></a>
		                <a href="s.html" target="right"><d1><h2>Search </h2></a>
	</body>
</html>

