<?php
$t=$_GET['n'];


$con=pg_connect("host=localhost user=project password=pro123 dbname=pro") or die("unable to connect database");

echo "<br>Temperature Information on time : $t <br> <br> ";

if(isset($t))
{
	$qry1 = "select * from tempdb where time='$t' ";
	$rs1=pg_query($con,$qry1) or die("problem in select Query");

	echo "<TABLE border=1>    <font color='white'>";
	echo "<TR><TH>DATE</TH><TH>TIME</TH><TH>DEGREE</TH><TH>HUMIDITY</TH></TR>";
	while( $rec = pg_fetch_assoc($rs1) )
	{
		$r=$rec['date'];
		$n=$rec['time'];
		$p=$rec['degree'];
		$h=$rec['humidity'];
		echo "<TR>";
		echo "<TD> $r </TD>";
		echo "<TD> $n </TD>";
		echo "<TD> $p </TD>";
		echo "<TD> $h </TD>";

		echo "</TR>";
	}

	echo "<br> <br> ";
}



pg_close($con);
?>
