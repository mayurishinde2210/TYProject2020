<html>
	<center>
	<frameset cols="30%,*">
		<frame name="left" src="f1.php">
		<frame name="right">
	</frameset>
	<noframes>
		<body>


  <a href="l2try.php" width="100"><img src="pre.png" alt="PREVIOUS" style="width:80px;height:80px;margin-left:0px;border:0">



			Browser Does NOT support frameset....
			so CHANGE the Browser...
		</body>
		<noframes>
	</center>
</html>
