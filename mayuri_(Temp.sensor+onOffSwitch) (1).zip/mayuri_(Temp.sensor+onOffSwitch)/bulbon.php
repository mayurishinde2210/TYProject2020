<!DOCTYPE html>
<pre>
<html>
<head>
<style>
h1 {
  text-shadow: 2px 5px red ;
          font-size:40px;

}
.button
{
        margin-right:300px;
                margin-top:70px;
        float:right;

}

</style>


<SCRIPT>
	function ON_display()
{
	var n = document.getElementById('n').value;
	var x = new XMLHttpRequest();
	x.open("GET", "ad.php?n="+n,true);
	x.send();
	x.onreadystatechange= function()
	{
		if(x.readyState==4 && x.status ==200)
		{
			document.getElementById("msg").innerHTML=x.responseText;
		}
	}
}

function OFF_display()
{
	var n = document.getElementById('a').value;
	var x = new XMLHttpRequest();
	x.open("GET", "ad.php?n="+n,true);
	x.send();
	x.onreadystatechange= function()
	{
		if(x.readyState==4 && x.status ==200)
		{
			document.getElementById("msg").innerHTML=x.responseText;
		}
	}
}

</SCRIPT>
</head>
        <body bgcolor="aqua">

                <center>

	<center>
<h1> ON / OFF  SWITCH</h1>


<img id="myImage" src="b1.png" style="width:150px">


<button  name="n" id="n" value="ON" onclick="ON_display()" onmouseout="document.getElementById('myImage').src='b2.png'">Turn ON</button>	<button name="a" id="a" value="OFF" onclick="OFF_display()" onmouseout="document.getElementById('myImage').src='b1.png'">Turn OFF </button>





<p id="msg"> </p>







	</center>
</body>
</html>
