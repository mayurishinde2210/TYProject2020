<!DOCTYPE html>
<html>
<head>
<style>
body {
  font-family: 'Lato';
}

h1 {
  text-shadow: 0  5px #FF0000, 0  10px #8B0000;
	font-size:80px;
}


.overlay {
  height: 100%;
  width: 0;
  position: fixed;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0, 0.9);
  overflow-x: hidden;
  transition: 0.5s;
}

.overlay-content {
  position: relative;
  top: 25%;
  width: 100%;
  text-align: center;
  margin-top: 30px;
}

.overlay a {
  padding: 8px;
  text-decoration: none;
  font-size: 36px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.overlay .closebtn {
  position: absolute;
  top: 20px;
  right: 45px;
  font-size: 60px;
}

</style>
</head>
<body>
<div id="myNav" class="overlay">
  <a href="javascript:void(0)"  class="closebtn" onclick="closeNav()">&times;</a>
  <div class="overlay-content">
    <a href="about.html">About</a>
    <a href="bulbon.php">Switch</a>

    <a href="f.php">Display</a>
    <a href="contacts.php">Contact</a>
  </div>
</div>



<span style="font-size:30px;cursor:pointer" onclick="openNav()"> &#9776; open
</span>


<center>
	<blink>	<h1>Temperature Sensor<br> <br>
		+<br><br>
     On Off
     Switch</h1>
</center>
<script>
function openNav() {
  document.getElementById("myNav").style.width = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.width = "0%";
}
</script>
     
</body>
</html>

