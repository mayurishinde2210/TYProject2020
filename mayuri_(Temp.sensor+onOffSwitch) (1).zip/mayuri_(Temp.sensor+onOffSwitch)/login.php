<?php
 $user=$_POST['s1'];
$pass=$_POST['s2'];
  if($user=="Project" && $pass=="123")
  {
       header('Location:l2try.php');
  }
  else
  {
	  echo"<center><b><br>";
	  echo"Incorrect Username & Password !!!!!<br><br>";
	  echo"ReEnter Username & Password.....";
  	
	  echo"</b></center>";
  }
?> 
