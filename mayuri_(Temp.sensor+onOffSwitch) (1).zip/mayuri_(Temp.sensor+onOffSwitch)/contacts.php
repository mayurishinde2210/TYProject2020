<pre>
<html>
<body>
<center>
<img src="contact.jpeg" height="500" width="1000">
<font size="10"><b><i>mayurishinde2210@gmail.com
&
bhosaleaditya170@gmail.com
<h1><font color="red"></i> THANK YOU...</h1></b></font>
</center>
</body>
</html>
</pre>
